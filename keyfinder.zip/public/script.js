const API = "http://localhost:3000/api";
const BASE_URL = "http://localhost:3000";
let token = localStorage.getItem("token") || null;


// Primero obtener todas las referencias DOM
const tokenInfo = document.getElementById("tokenInfo");
const formProp = document.getElementById("form-prop"); // ✅ Ahora está definido
const btnLogout = document.getElementById("btn-logout");

/* ========== Helpers Mejorados ========== */
async function request(path, method = "GET", data = null) {
  const opts = { method, headers: {} };

  if (!(data instanceof FormData)) {
    opts.headers["Content-Type"] = "application/json";
    if (data) opts.body = JSON.stringify(data);
  } else {
    opts.body = data;
  }

  if (token) opts.headers.Authorization = `Bearer ${token}`;

  try {
    const res = await fetch(`${API}${path}`, opts);
    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      throw new Error(
        errorData.message || 
        errorData.error || 
        `Error ${res.status}: ${res.statusText}`
      );
    }
    return await res.json();
  } catch (err) {
    console.error("Error en la petición:", {
      path,
      method,
      error: err.message
    });
    throw err;
  }
}

/* ========== Publicar Propiedad (Versión Mejorada) ========== */
formProp.addEventListener("submit", async e => {
  e.preventDefault();
  const submitBtn = formProp.querySelector('button[type="submit"]');
  const originalText = submitBtn.textContent;
  
  try {
    submitBtn.disabled = true;
    submitBtn.textContent = "Publicando...";
    
    // 1. Crear FormData con nombre de campo correcto
    const formData = new FormData(formProp);
    console.log("Datos a enviar:", {
      titulo: formData.get('titulo'),
      imagenes: formData.getAll('imagenes') // o 'imagen' según tu backend
    });

    // 2. Hacer la petición con timeout
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);
    
    const response = await fetch(`${API}/propiedades`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`
      },
      body: formData,
      signal: controller.signal
    });
    clearTimeout(timeout);

    // 3. Manejar respuesta
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error("Error del servidor:", {
        status: response.status,
        data: errorData
      });
      throw new Error(errorData.message || `Error ${response.status}`);
    }

    const result = await response.json();
    console.log("Respuesta exitosa:", result);
    
    formProp.reset();
    document.getElementById('preview-container').innerHTML = '';
    cargarPropiedades();
    alert(`✅ Propiedad publicada con ID: ${result.id}`);

  } catch (err) {
    console.error("Error completo:", {
      name: err.name,
      message: err.message,
      stack: err.stack
    });
    
    let errorMessage = "Error al publicar propiedad";
    if (err.name === "AbortError") {
      errorMessage = "La petición tardó demasiado (más de 15 segundos)";
    } else if (err.message.includes("500")) {
      errorMessage = "Error interno del servidor (revisa la consola del servidor)";
    } else if (err.message) {
      errorMessage = err.message;
    }
    
    alert(`❌ ${errorMessage}`);
    
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = originalText;
  }
});

/* ========== Cargar Propiedades (Versión Mejorada) ========== */
async function cargarPropiedades() {
  const cont = document.getElementById("props");
  cont.innerHTML = "<p>Cargando propiedades...</p>";

  try {
    const lista = await request("/propiedades");
    cont.innerHTML = "";
    
    if (lista.length === 0) {
      cont.innerHTML = "<p>No hay propiedades disponibles</p>";
      return;
    }

    lista.forEach(p => {
      const imagesHTML = p.imagen_url 
        ? `<img src="${BASE_URL}${p.imagen_url}" alt="${p.titulo}" class="property-img">`
        : "";
      
      cont.insertAdjacentHTML("beforeend", `
        <div class="card">
          <h3>${p.titulo}</h3>
          <p><strong>$${p.precio?.toLocaleString() || '0'}</strong> — ${p.tipo || 'Sin tipo'}</p>
          ${imagesHTML}
          <p>${p.descripcion || ""}</p>
          <small>${new Date(p.fecha_publicacion).toLocaleDateString()}</small>
        </div>
      `);
    });
  } catch (err) {
    console.error("Error al cargar propiedades:", err);
    cont.innerHTML = `<p class="error">Error al cargar propiedades: ${err.message}</p>`;
  }
}
// utils/auth.js (o en tu archivo principal de JS)
async function getUserId() {
  try {
    const token = localStorage.getItem('token');
    if (!token) {
      throw new Error('No hay token de autenticación');
    }

    const response = await fetch('/api/users/me/id', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    if (!response.ok) {
      throw new Error('Error al obtener ID de usuario');
    }

    const data = await response.json();
    return data.id;
  } catch (error) {
    console.error('Error en getUserId:', error);
    // Redirigir al login si no está autenticado
    window.location.href = '/login.html';
    return null;
  }
}
/* ====== FAVORITOS ====== */
document.getElementById("form-fav").addEventListener("submit", async e => {
  e.preventDefault();
  
  try {
    // 1. Obtener el ID del usuario
    const usuario_id = await getUserId();
    if (!usuario_id) {
      alert('Debes iniciar sesión para añadir favoritos');
      return;
    }

    // 2. Obtener el ID de la propiedad
    const propiedad_id = e.target.propiedad_id.value;
    if (!propiedad_id) {
      alert('No se especificó la propiedad');
      return;
    }

    // 3. Enviar la petición al servidor
    const response = await fetch('/api/favoritos', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify({ propiedad_id, usuario_id })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Error al añadir favorito');
    }

    // 4. Mostrar feedback al usuario
    alert("Añadido a favoritos correctamente");
    
    // Opcional: Actualizar la UI
    const favButton = e.target.querySelector('button');
    favButton.textContent = '★ En favoritos';
    favButton.disabled = true;

  } catch (error) {
    console.error('Error al añadir favorito:', error);
    alert(error.message);
  }
});

/* ====== RESEÑAS ====== */
document.getElementById("form-resena").addEventListener("submit", async e => {
  e.preventDefault();
  
  // Obtener el ID del usuario autenticado
  const userId = await getUserId(); // Asumiendo que tienes esta función
  
  const data = {
    propiedad_id: e.target.propiedad_id.value,
    user_id: userId, // Añadir el user_id
    comentario: e.target.comentario.value,
    calificacion: parseInt(e.target.puntuacion.value) // Cambiar "puntuacion" a "calificacion" para coincidir con el backend
  };
  
  await request("/resenas", "POST", data);
  alert("Reseña publicada");
  e.target.reset(); // Limpiar el formulario
});

async function verResenas(propiedadId) {
  const resenas = await request(`/resenas/propiedad/${propiedadId}`); // Cambiar la ruta
  document.getElementById("lista-resenas").innerHTML = resenas
    .map(r => `
      <div class="resena">
        <strong>Usuario ${r.user_id}</strong>:
        <span>${r.comentario}</span>
        <small>${r.calificacion}/5 - ${new Date(r.fecha_resena).toLocaleDateString()}</small>
      </div>
    `)
    .join("");
}

/* ====== MENSAJES ====== */
document.getElementById("form-mensaje").addEventListener("submit", async e => {
  e.preventDefault();
  
  // Obtener el ID del usuario autenticado
  const emisorId = await getUserId();
  
  const data = {
    emisor_id: emisorId, // Cambiar de remitente_id a emisor_id para coincidir con BD
    receptor_id: e.target.destinatario_id.value, // Cambiar de destinatario_id a receptor_id
    contenido: e.target.contenido.value
  };
  
  await request("/mensajes", "POST", data);
  alert("Mensaje enviado");
  e.target.reset(); // Limpiar el formulario
});

async function verMensajes(otroUsuarioId) {
  const usuarioActualId = await getUserId();
  const mensajes = await request(`/mensajes/${usuarioActualId}/${otroUsuarioId}`);
  
  document.getElementById("lista-mensajes").innerHTML = mensajes
    .map(m => `
      <div class="mensaje ${m.emisor_id === usuarioActualId ? 'enviado' : 'recibido'}">
        <p>${m.contenido}</p>
        <small>${new Date(m.fecha_envio).toLocaleString()}</small>
      </div>
    `)
    .join("");
}
/* ====== Helper ====== */
function getUserId() {
  if (!token) return null;
  try {
    const payload = JSON.parse(atob(token.split(".")[1]));
    return payload.id;
  } catch {
    return null;
  }
}
